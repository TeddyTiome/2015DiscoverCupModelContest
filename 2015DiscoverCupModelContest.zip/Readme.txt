The package includes
1.	Data in TXT format.
2.	Detail description on contest data.
3.	Business problem need to be solved and evaluation criteria used to measure the prediction accuracy.
4.	Template of model document to summarize key information of the business solution.
5.	Template of submission to fill in prediction of the business problem.


